-- AlterTable
ALTER TABLE "systems" ALTER COLUMN "status" SET DEFAULT E'on';

-- AlterTable
ALTER TABLE "users" ALTER COLUMN "user_role" SET DEFAULT E'user';
