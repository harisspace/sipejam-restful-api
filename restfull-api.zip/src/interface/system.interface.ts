export const SelectSystem = {
  id: true,
  system_uid: true,
  name: true,
  placed: true,
  system_maker: true,
  image_uri: true,
  status: true,
  aplication_id: true,
  created_at: true,
  updated_at: true,
};
