export const SelectUser = {
  id: true,
  user_uid: true,
  username: true,
  email: true,
  user_role: true,
  image_uri: true,
  confirmed: true,
  created_at: true,
  updated_at: true,
};
